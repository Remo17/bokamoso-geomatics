---
name: Precision Architectural Geomatics
colors:
  surface: '#fcf8f8'
  surface-dim: '#ddd9d9'
  surface-bright: '#fcf8f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f1eded'
  surface-container-high: '#ebe7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#44474a'
  inverse-surface: '#313030'
  inverse-on-surface: '#f4f0ef'
  outline: '#75777a'
  outline-variant: '#c5c6ca'
  surface-tint: '#5d5e61'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1a1c1e'
  on-primary-container: '#838486'
  inverse-primary: '#c6c6c9'
  secondary: '#4a6546'
  on-secondary: '#ffffff'
  secondary-container: '#c9e8c1'
  on-secondary-container: '#4e6a4a'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#201b16'
  on-tertiary-container: '#8b827c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2e2e5'
  primary-fixed-dim: '#c6c6c9'
  on-primary-fixed: '#1a1c1e'
  on-primary-fixed-variant: '#454749'
  secondary-fixed: '#ccebc4'
  secondary-fixed-dim: '#b0cfa9'
  on-secondary-fixed: '#072108'
  on-secondary-fixed-variant: '#334d30'
  tertiary-fixed: '#ece0d9'
  tertiary-fixed-dim: '#cfc4be'
  on-tertiary-fixed: '#201b16'
  on-tertiary-fixed-variant: '#4c4540'
  background: '#fcf8f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
  background-stone: '#F5F3EE'
  surface-dark: '#16181A'
  surface-dark-elevated: '#212427'
  surface-light: '#FFFFFF'
  border-light: '#E2E0D8'
  border-dark: '#2E3136'
  text-primary-dark: '#16181A'
  text-muted-dark: '#716E67'
  text-primary-light: '#FFFFFF'
  text-muted-light: '#8E9297'
  technical-green: '#3F5A3C'
typography:
  hero-title:
    fontFamily: Inter
    fontSize: 56px
    fontWeight: '400'
    lineHeight: 64px
    letterSpacing: -0.03em
  hero-title-mobile:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 44px
    letterSpacing: -0.02em
  section-title:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
    letterSpacing: -0.02em
  section-title-mobile:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: '400'
    lineHeight: 34px
    letterSpacing: -0.01em
  kicker:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.08em
  item-title:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-lead:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-regular:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-muted:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  table-data:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  technical-caption:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.06em
  brand-title:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.14em
spacing:
  gutter: 1.5rem
  margin: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The visual identity embodies the discipline, exactitude, and scientific rigor of land surveying, geodesy, and spatial engineering. Rooted in cartographic precision and technical clarity, the brand addresses civil engineering contractors, mining operators, municipal authorities, and property developers who demand unquestionable spatial accuracy.

The aesthetic fuses **Editorial Minimalism** with **Technical Architectural Cartography**:
- **Monochromatic and Terrestrial**: High-contrast deep carbon black (`#16181A`) and pure white (`#FFFFFF`) grounded by warm natural stone (`#F5F3EE`) reflecting soil and survey terrain.
- **Cartographic Accents**: Technical notation strings (e.g., `25.67° S · 27.24° E`), index prefixes (`01`, `02`, `A`, `B`), middle-dot interpuncts (`·`), and figure callouts (`Fig. 01 — Topographic survey area`).
- **Precision Structure**: Crisp 1px hairline borders (`#E5E5E5`, `#26282B`), structural horizontal dividers, tabular metadata layouts, and clean diagonal vector indicators (`↗`).
- **Strictly Non-Decorative**: Complete absence of playful rounded pills, glowing drop shadows, heavy gradient fills, or generic corporate SaaS cards. Every element behaves like a field plate, index log, or technical surveyor's record.

## Colors

The color system operates on alternating high-contrast thematic surfaces that demarcate functional zones across the survey narrative:

- **Surface Dark (`#16181A`)**: Represents authoritative grounding. Used for global navigation bars, hero sections, quality assurance matrix backgrounds, and multi-column technical footers. Typography atop this surface relies on pure white (`#FFFFFF`) for primary headings and technical muted gray (`#8E9297`) for labels and coordinates.
- **Surface Stone (`#F5F3EE`)**: A warm, tactile limestone/sand tone used for index sections, project data logs, and editorial contact blocks. Delivers an organic architectural quality without the sterility of pure white.
- **Surface Light (`#FFFFFF`)**: Crisp, sterile background for technical service registries and data capture fields.
- **Technical Green (`#3F5A3C`)**: A deep topographic forest green reserved for subtle status confirmations, verified survey credentials, or active selection highlights.
- **Hairline Dividers (`#E2E0D8` on light / `#2E3136` on dark)**: Clean 1px rules that delineate tabular rows, header borders, and architectural grid limits.

## Typography

Typography functions as both information hierarchy and structural geometry:

- **Primary Sans (`Inter`)**: Set with balanced, slightly tightened tracking (`-0.01em` to `-0.03em`) on large display titles for a modern European architectural appearance. Standard body weights remain light to regular (`400`), ensuring long-form descriptions read like clean survey documentation.
- **Technical Monospace (`JetBrains Mono`)**: Governs structural markers, coordinates (`25.67° S · 27.24° E`), section kickers (`01 — INTRODUCTION`), figure tags (`Fig. 01 — Topographic survey area`), and index digits (`01`, `02`). It imparts an authentic instrument-readout demeanor.
- **Brand Logotype**: All-caps tracking (`0.14em`), bold geometric sans (`BOKAMOSO GEOMATICS`), anchored firmly at the top-left and bottom-left bounds.
- **Formatting Conventions**: Section titles are consistently preceded by numeric indicators separated by an em-dash (`01 — Introduction`). Metadata points are uniformly divided by middle dots (`·`).

## Layout & Spacing

The layout is built upon an architectural grid with uncompromising horizontal and vertical alignment:

- **Grid System**: 12-column desktop grid with 24px gutters and 32px safe margins (expanding to max-width containers of 1280px with auto margins). On mobile devices, the system condenses into a 4-column layout with 16px margins.
- **Rhythmic Section Alternation**: Sections transition between dark `#16181A`, neutral stone `#F5F3EE`, and crisp `#FFFFFF`, creating distinct survey plates.
- **Modular Data Rows**: Repeatable rows (such as Services and Selected Projects) utilize full-bleed horizontal hairlines with vertical padding (`space-lg` to `space-xl`), allowing items to function as tabular records with left-aligned indices, central service descriptions, and right-aligned action vectors (`↗`).
- **Cartographic Overlays**: Figure captions are pinned to the bottom right or bottom left of imagery plates with semi-opaque dark backing (`rgba(22, 24, 26, 0.85)`), mirroring official survey field photographs.

## Elevation & Depth

This design system rejects skeuomorphic shadows, soft blur halos, and multi-tier ambient elevations in favor of **Structural Planar Depth**:

- **Low-Contrast Outlines & Rule Dividers**: Depth is created strictly through 1px planar rules (`#E2E0D8` against stone/white, and `#2E3136` against dark charcoal). Elements exist on physical technical planes rather than floating above each other.
- **Surface Tiering**: Distinct contrast boundaries indicate functional zoning. For example, a form container on a stone background uses a crisp white background enclosed in a 1px border.
- **High-Density Data Plate Overlays**: Technical callout chips (e.g., `Fig. 01 — Topographic survey area`) use solid, razor-sharp dark overlays with no blur, resting directly on the photographic substrate.
- **Interactive State Depth**: Interactive table rows and buttons undergo flat color shifts (e.g., `#F5F3EE` shifting to `#ECE9E1`, or dark buttons shifting to `#2A2D31`) without vertical translation or shadow expansion.

## Shapes

The shape system is strictly **Sharp (`roundedness: 0`)**:

- Every button, card, input box, dialog, and image container features explicit **0px border radius**.
- Sharp 90-degree corners communicate engineering accuracy, cadastre boundaries, and blueprint plotting lines.
- Pill tags, circular chips, and rounded corners are strictly prohibited. Even coordinate badges and discipline tags use rectilinear geometries enclosed in 1px hairline borders.

## Components

### Buttons & CTAs
- **Primary Dark Button**: Sharp rectangle, background `#16181A`, foreground `#FFFFFF`, 1px border `#16181A`. Padding: 12px 20px. Contains clean uppercase or title-case text followed by the diagonal arrow glyph (`↗`). Hover: background `#2A2D31`.
- **Secondary Outline Button**: Sharp rectangle, background transparent, 1px border `#16181A` (on light) or `#FFFFFF` (on dark), text matching the border color. Hover: invert background and text.
- **Inline Action Vectors**: Single line link accompanied by `↗` that transitions 2px upward and rightward on hover.

### Navigation Header
- **Layout**: Fixed or relative top bar spanning the full canvas. 1px bottom border (`#2E3136` or `#E2E0D8`).
- **Left**: Bold brandmark (`BOKAMOSO GEOMATICS`) in tracking-spaced uppercase sans-serif.
- **Center**: Editorial text links (`About`, `Services`, `Projects`, `Expertise`, `Contact`) with subtle hover opacity change.
- **Right**: Primary action button (`Request a Quote ↗`).

### Tabular Service & Project Rows
- **Structure**: Continuous full-width rows divided by 1px horizontal borders.
- **Columns (Desktop)**:
  - Column 1: Index identifier (`01`, `02`, etc.) in monospace.
  - Column 2: Service/Project Title in medium weight sans-serif.
  - Column 3: Detailed technical description or category/municipality metadata.
  - Column 4: Year / Location or trailing diagonal vector icon (`↗`).
- **Hover**: Background subtle tint highlight (`rgba(0,0,0,0.02)` on light; `rgba(255,255,255,0.03)` on dark).

### Form Fields (Request a Quote & Contact)
- **Inputs & Textareas**: Sharp rectangular containers with 1px border `#E2E0D8`, background `#FFFFFF`. Height: 44px for single-line inputs. Padding: 12px 14px. Focus state: border color `#16181A` with 0px outline.
- **Labels**: Technical monospace or small crisp sans (`12px`, uppercase, tracking `0.05em`), placed strictly above the field.
- **Select Menus**: Sharp dropdowns featuring custom chevron indicator, retaining identical borders and heights.

### Quality Assurance & Discipline Matrix
- **Cards**: Sharp bordered blocks or open grid cells separated by 1px rules.
- **Headers**: Lettered indicator (`A`, `B`, `C`, `D`) in monospace above an H3 title (`16px`, medium weight).
- **Body**: Concise 2-3 line operational descriptions explaining review rigor and compliance standards.

### Technical Imagery Containers
- Aerial drone photos and contour maps are framed in razor-sharp rectangular viewports.
- Image overlays feature anchored monospace captions (`Fig. 01 — Topographic survey area`) in dark high-contrast badges located in bottom corners.

### Footer
- **Theme**: Dark `#16181A` background with crisp white typography.
- **Layout**: 4-column architectural schema:
  - Col 1: Brand title, core practice statement, and cadastral coverage.
  - Col 2: Head Office address details (Rustenburg, North West).
  - Col 3: Satellite Office address details.
  - Col 4: Contact channels (phone lines, direct email).
- **Bottom Bar**: 1px top border, full copyright statement with middle dot delimiters (`© Bokamoso Geomatics · Rustenburg, North West, South Africa`).